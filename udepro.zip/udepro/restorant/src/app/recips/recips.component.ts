import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recips',
  templateUrl: './recips.component.html',
  styleUrls: ['./recips.component.css']
})
export class RecipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
